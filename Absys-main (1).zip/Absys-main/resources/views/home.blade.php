




{{-- -------     this page developed by vue js      ------- --}}
<x-layout>

    <dashboard />


</x-layout>

{{-- ---------------       Fin       -------------------------}}