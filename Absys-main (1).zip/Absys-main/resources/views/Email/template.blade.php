


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>
<body>
    <div>
        <h3>Compte Absys Ofppt</h3>
        <h1>Code de réinitialisation de mot de passe</h1>



        <h4>Bonjour {{$nom}} {{$prenom}} </h4>

        <p>Utilisez ce code pour réinitialiser le mot de passe de votre compte Absys ofppt</p>
        
    
        <p>Voici votre code : {{ $code }}</p>

        <p>Merci,</p>
        <p>L’équipe des comptes Absys Ofppt</p>
    </div>
</body>
</html>
