<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
   <table border="1">
    <tr>
        <th>nom</th>
        <th>prenom</th>
        <th>Age</th>
    </tr>
    <tr>
        <td>dabibe</td>
        <td>Anas</td>

    </tr>
   </table>
   <button onclick="window.print()">print</button>
</body>
</html>