
@php

    $class="w-full px-6 py-2.5 bg-gray-800 text-white font-medium text-xs leading-tight uppercase rounded
    shadow-md  focus:bg-gray-700 focus:shadow-lg focus:outline-none focus:ring-0 hover:bg-black-800        
    hover:shadow-lg active:bg-gray-700 active:shadow-lg transition duration-150 ease-in-out";

@endphp

<button {{ $attributes->merge(['class' => $class]) }}>Se connecter</button>
        

           
      
           
           
           
           
           
           
           
            

            
                        
            